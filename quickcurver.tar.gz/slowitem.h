//#ifndef SLOWITEM_H
//#define SLOWITEM_H
//#include "curveitem.h"
//#include <QSGNode>


//class SlowItem : public CurveItem
//{
//public:
//	SlowItem(QSGNode* node);
//};

//#endif // SLOWITEM_H
