//#include "slowitem.h"

//SlowItem::SlowItem(QSGNode *node) {
//	CurveItem(node);
//}
